class cliente:

    def __init__(self, nombre, apellido, edad, dni, telefono, email):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.dni = dni
        self.telefono = telefono
        self.email = email
        self.intereses = []

    def info_cliente(self):
        print("Nombre: ", self.nombre)
        print("Apellido: ", self.apellido)
        print("Edad: ", self.edad)
        print("Dni: ",self.dni)
        print("Tel: ",self.telefono)
        print("E-mail: ",self.email)
        print("Intereses: ",self.intereses)

# Compra
    def comprar(self, cantidad, producto, tienda):
        return f"\nEl cliente {self.nombre} {self.apellido} compró {cantidad} {producto} en la tienda de {tienda}.\nLos detalles de la factura fueron enviados al mail {self.email}."
    
def __str__(self):
        return f"\nHola, mi nombre es {self.nombre} {self.apellido}, tengo {self.edad} años, \nDNI: {self.dni}.\ntelefono: {self.telefono}.\n E-mail: {self.email}.\n mis intereses son: {self.intereses}."