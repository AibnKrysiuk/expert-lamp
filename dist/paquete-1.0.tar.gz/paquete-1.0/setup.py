from setuptools import setup

setup(

    name="paquete",
    version = "1.0",
    description = "Paquete distribuido con cliente, producto y login",
    author = "Iván Krysiuk",
    author_email = "ivan.krysiuk.93@gmail.com",

    packages = ["paquete"]
)